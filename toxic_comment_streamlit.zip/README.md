# Toxic Comment Streamlit App

This project provides a simple web interface to classify comments as **toxic** or **non‑toxic** using a pre‑trained Logistic Regression model.

## How to deploy on Streamlit Cloud
1. **Fork / Clone** this repository to your GitHub.
2. Add the following two binary files trained locally or on Colab:
   - `logistic_model.pkl`
   - `tfidf_vectorizer.pkl`
3. Verify that `requirements.txt` includes all dependencies.
4. Go to [streamlit.io/cloud](https://streamlit.io/cloud), click **New app**, select your repo, and set **Main file** to `toxic_streamlit_app.py`.
5. Click **Deploy** – your app will build and be available at a public URL.

> **Tip:** Train and export the model in Colab:

```python
import joblib
joblib.dump(model, "logistic_model.pkl")
joblib.dump(tfidf, "tfidf_vectorizer.pkl")
```

Then download the `.pkl` files and commit them to your repository.
